#sudo apt-get install python3-tk
import turtle
from operator import add

RED = (1.0, 0.0, 0.0)
GREEN = (0.0, 1.0, 0.0)
SUM = map(add, RED, GREEN)

TRIANGLE_SIZE = 200
BORDER_SIZE = 3
BORDER_SIZE1 = 2

STAMP_UNIT = 20
SQRT_3 = 3 ** 0.5

turtle.shape("triangle")
turtle.hideturtle()
turtle.penup()
turtle.right(30)  # realign triangle
turtle.fillcolor("#fff")
turtle.shapesize(TRIANGLE_SIZE / STAMP_UNIT, TRIANGLE_SIZE / STAMP_UNIT, BORDER_SIZE)
turtle.stamp()

TRIANGLE_SIZE1 = 50
turtle.fillcolor("#fff")
y_offset = TRIANGLE_SIZE * 1 / 4
turtle.goto(80, -y_offset)
turtle.shapesize(TRIANGLE_SIZE1 / STAMP_UNIT, TRIANGLE_SIZE1 / STAMP_UNIT, BORDER_SIZE1)
turtle.stamp()

TRIANGLE_SIZE1 = 50
turtle.fillcolor("#fff")
y_offset = TRIANGLE_SIZE * 1 / 4
turtle.goto(-80, -y_offset)
turtle.shapesize(TRIANGLE_SIZE1 / STAMP_UNIT, TRIANGLE_SIZE1 / STAMP_UNIT, BORDER_SIZE1)
turtle.stamp()

TRIANGLE_SIZE1 = 50
turtle.fillcolor("#fff")
y_offset = TRIANGLE_SIZE * 1 / 4
turtle.goto(0, 90)
turtle.shapesize(TRIANGLE_SIZE1 / STAMP_UNIT, TRIANGLE_SIZE1 / STAMP_UNIT, BORDER_SIZE1)
turtle.stamp()

# turtle.shapesize(TRIANGLE_SIZE / STAMP_UNIT / 2, TRIANGLE_SIZE / STAMP_UNIT / 2, BORDER_SIZE)
# turtle.fillcolor(SUM)
# turtle.sety(turtle.ycor() + 2 * y_offset / 3)
# turtle.stamp()

turtle.exitonclick()
